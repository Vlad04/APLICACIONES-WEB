<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rutina extends Model
{
    //
}
