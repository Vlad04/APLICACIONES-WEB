function toRegister() {
    window.location.replace('/registro');
}