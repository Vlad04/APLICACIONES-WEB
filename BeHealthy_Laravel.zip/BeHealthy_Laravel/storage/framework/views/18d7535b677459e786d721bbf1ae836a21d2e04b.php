<footer class="page-footer font-small blue pt-4 mt-4" style="background-color: #272424; font-size: 120%;">
    <div class="container-fluid text-center text-md-left">
        <div class="row">
            <div class="col-md-6">
                <h5 class="text-uppercase" style="font-family: 'Lobster', cursive;">Be Healthy</h5>
                <p style="font-family: 'Poppins', cursive; font-size: 75%;">Todos los contenidos de este Sitio (Incluyendo, pero no limitado a, texto, logotipos, contenido, fotografías, audio, botones, nombres comerciales y vídeo) están sujetos a derechos de propiedad por las leyes de Derechos de Autor y demás Leyes relativas Internacionales.</p>
            </div>
            <div class="col-md-6">
                <h5 class="text-uppercase">Links</h5>
                <ul class="list-unstyled">
                    <li>
                        <a href="#!">Facebook</a>
                    </li>
                    <li>
                        <a href="#!">Twitter</a>
                    </li>
                    <li>
                        <a href="#!">Instagram</a>
                    </li>
                    <li>
                        <a href="#!">Youtube</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright py-3 text-center">
        © 2018 Copyright:
        <a href="https://mdbootstrap.com/material-design-for-bootstrap/"> BeHealthy.com </a>
    </div>
</footer>
<?php echo $__env->yieldContent('Footer'); ?>